import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:math' as math;

class EnergyCore extends StatefulWidget {
  final double progress; // 0.0 to 1.0 (session progress)
  final bool isListening;

  const EnergyCore({
    super.key,
    required this.progress,
    required this.isListening,
  });

  @override
  State<EnergyCore> createState() => _EnergyCoreState();
}

class _EnergyCoreState extends State<EnergyCore>
    with SingleTickerProviderStateMixin {
  late AnimationController _rotationController;

  @override
  void initState() {
    super.initState();
    _rotationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
  }

  @override
  void dispose() {
    _rotationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Colors evolve as progress increases
    final Color coreColor = Color.lerp(
      const Color(0xFF00E676), // Green (Initial)
      const Color(0xFF6C63FF), // Purple/Electric Blue (Final)
      widget.progress,
    )!;

    // Intensity/Size evolves as progress increases
    final double baseSize = 60.0 + (widget.progress * 40.0);
    final double glowRadius = 20.0 + (widget.progress * 30.0);

    return SizedBox(
      height: 140,
      width: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // 1. External Aura (Subtle pulse)
          Container(
                width: baseSize + glowRadius,
                height: baseSize + glowRadius,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: coreColor.withValues(alpha: 0.15),
                      blurRadius: glowRadius * 2,
                      spreadRadius: 5,
                    ),
                  ],
                ),
              )
              .animate(onPlay: (c) => c.repeat(reverse: true))
              .scale(
                begin: const Offset(0.9, 0.9),
                end: const Offset(1.1, 1.1),
                duration: 2.seconds,
              ),

          // 2. Rotating Particles (Mocking internal energy)
          AnimatedBuilder(
            animation: _rotationController,
            builder: (context, child) {
              return Transform.rotate(
                angle: _rotationController.value * 2 * math.pi,
                child: CustomPaint(
                  size: Size(baseSize, baseSize),
                  painter: _EnergyParticlesPainter(
                    color: coreColor,
                    progress: widget.progress,
                  ),
                ),
              );
            },
          ),

          // 3. The Core Sphere (Glassmorphic)
          Container(
                width: baseSize,
                height: baseSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      Colors.white.withValues(alpha: 0.8),
                      coreColor.withValues(alpha: 0.5),
                      coreColor.withValues(alpha: 0.1),
                    ],
                    stops: const [0.0, 0.4, 1.0],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: coreColor.withValues(alpha: 0.4),
                      blurRadius: glowRadius,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              )
              .animate(target: widget.isListening ? 1 : 0)
              .shake(
                hz: 4,
                curve: Curves.easeInOut,
              ), // Slight shake when listening
          // 4. Listening Ring
          if (widget.isListening)
            Container(
                  width: baseSize + 10,
                  height: baseSize + 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white24, width: 1),
                  ),
                )
                .animate(onPlay: (c) => c.repeat())
                .scale(
                  begin: const Offset(1, 1),
                  end: const Offset(1.5, 1.5),
                  duration: 1.seconds,
                )
                .fadeOut(duration: 1.seconds),
        ],
      ),
    );
  }
}

class _EnergyParticlesPainter extends CustomPainter {
  final Color color;
  final double progress;

  _EnergyParticlesPainter({required this.color, required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color.withValues(alpha: 0.6);
    final random = math.Random(42); // Fixed seed for stable particles

    final count = (15 + (progress * 20)).toInt();
    final radius = size.width / 2;

    for (int i = 0; i < count; i++) {
      final angle = random.nextDouble() * 2 * math.pi;
      final dist = random.nextDouble() * radius;
      final pSize = random.nextDouble() * 3 + 1;

      final x = size.width / 2 + math.cos(angle) * dist;
      final y = size.height / 2 + math.sin(angle) * dist;

      canvas.drawCircle(Offset(x, y), pSize, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
