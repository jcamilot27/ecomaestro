import 'package:flutter/material.dart';

class FluencyThermometer extends StatefulWidget {
  final double warmthLevel; // 0.0 to 1.0

  const FluencyThermometer({super.key, required this.warmthLevel});

  @override
  State<FluencyThermometer> createState() => _FluencyThermometerState();
}

class _FluencyThermometerState extends State<FluencyThermometer>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
  }

  @override
  void didUpdateWidget(FluencyThermometer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.warmthLevel != widget.warmthLevel) {
      // Animate change if necessary
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Color _getColorForLevel(double level) {
    if (level < 0.3) return Colors.blueGrey;
    if (level < 0.6) return Colors.amber;
    if (level < 0.9) return Colors.orangeAccent;
    return Colors.redAccent; // "On Fire"
  }

  @override
  Widget build(BuildContext context) {
    // Calculate height based on parent constraints or fixed size
    return Container(
      width: 12,
      height: 200,
      decoration: BoxDecoration(
        color: Colors.grey[800],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          // Background/Empty state

          // Fluid Fill
          AnimatedContainer(
            duration: const Duration(milliseconds: 800),
            curve: Curves.fastOutSlowIn,
            width: 12,
            height: 200 * widget.warmthLevel,
            decoration: BoxDecoration(
              color: _getColorForLevel(widget.warmthLevel),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: _getColorForLevel(
                    widget.warmthLevel,
                  ).withValues(alpha: 0.6),
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
