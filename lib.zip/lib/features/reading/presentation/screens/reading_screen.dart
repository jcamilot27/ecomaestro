import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/di/service_locator.dart';
import '../bloc/reading_bloc.dart';
import '../widgets/fluency_thermometer.dart';
import '../widgets/energy_core.dart';

class ReadingScreen extends StatelessWidget {
  const ReadingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => sl<ReadingBloc>()..add(LoadReadingSession()),
      child: const _ReadingView(),
    );
  }
}

class _ReadingView extends StatefulWidget {
  const _ReadingView();

  @override
  State<_ReadingView> createState() => _ReadingViewState();
}

class _ReadingViewState extends State<_ReadingView> {
  bool _showSummary = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Práctica de Lectura'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: BlocConsumer<ReadingBloc, ReadingState>(
        listenWhen: (previous, current) =>
            previous.currentIndex != current.currentIndex ||
            previous.status != current.status,
        listener: (context, state) {
          if (state.status == ReadingStatus.initial) {
            Future.delayed(const Duration(milliseconds: 1000), () {
              if (context.mounted &&
                  context.read<ReadingBloc>().state.status ==
                      ReadingStatus.initial) {
                context.read<ReadingBloc>().add(StartListening());
              }
            });
          }

          if (state.status == ReadingStatus.success) {
            _showBubbleMessage(
              context,
              'Completado! Energía Verbal: ${(state.fluencyScore * 100).toInt()}%',
            );
          }

          if (state.status == ReadingStatus.sessionCompleted) {
            // Trigger explosion then show summary
            Future.delayed(const Duration(milliseconds: 1200), () {
              if (mounted) {
                setState(() {
                  _showSummary = true;
                });
              }
            });
          }

          if (state.status == ReadingStatus.failure &&
              state.errorMessage != null) {
            _showBubbleMessage(
              context,
              'Error: ${state.errorMessage}',
              isError: true,
            );
          }
        },
        builder: (context, state) {
          if (_showSummary) {
            return _buildSessionSummary(context, state);
          }

          return Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Energy Core or Explosion
                      if (state.status == ReadingStatus.sessionCompleted)
                        _buildExplosion(state)
                      else
                        EnergyCore(
                          progress: (state.currentIndex + 1) / state.totalTexts,
                          isListening: state.status == ReadingStatus.listening,
                        ),

                      const SizedBox(height: 32),

                      _buildHighlightedText(context, state.currentText, state),

                      const SizedBox(height: 48),

                      if (state.status == ReadingStatus.success)
                        FloatingActionButton.extended(
                          onPressed: () {
                            context.read<ReadingBloc>().add(NextText());
                          },
                          label: const Text("Siguiente Ejercicio"),
                          icon: const Icon(Icons.arrow_forward),
                        ).animate().fadeIn()
                      else if (state.status != ReadingStatus.sessionCompleted)
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            if (state.status == ReadingStatus.listening)
                              Container(
                                    width: 80,
                                    height: 80,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.redAccent.withValues(
                                        alpha: 0.2,
                                      ),
                                    ),
                                  )
                                  .animate(onPlay: (c) => c.repeat())
                                  .scale(
                                    begin: const Offset(1, 1),
                                    end: const Offset(1.8, 1.8),
                                    duration: 1000.ms,
                                    curve: Curves.easeOut,
                                  )
                                  .fadeOut(duration: 1000.ms),
                            FloatingActionButton(
                                  heroTag: "mic_btn",
                                  onPressed: () {
                                    if (state.status ==
                                        ReadingStatus.listening) {
                                      context.read<ReadingBloc>().add(
                                        StopReading(),
                                      );
                                    } else {
                                      context.read<ReadingBloc>().add(
                                        StartListening(),
                                      );
                                    }
                                  },
                                  backgroundColor:
                                      state.status == ReadingStatus.listening
                                      ? Colors.redAccent
                                      : Theme.of(context).colorScheme.primary,
                                  shape: const CircleBorder(),
                                  child: Icon(
                                    state.status == ReadingStatus.listening
                                        ? Icons.stop_rounded
                                        : Icons.mic_none_rounded,
                                    size: 32,
                                    color:
                                        state.status == ReadingStatus.listening
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                )
                                .animate(
                                  target:
                                      state.status == ReadingStatus.listening
                                      ? 1
                                      : 0,
                                )
                                .shimmer(
                                  duration: 2.seconds,
                                  color: Colors.white24,
                                ),
                          ],
                        ),
                    ],
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.only(
                  right: 16.0,
                  top: 40,
                  bottom: 40,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.local_fire_department,
                      color: Colors.orange,
                      size: 20,
                    ),
                    const SizedBox(height: 8),
                    FluencyThermometer(warmthLevel: state.fluencyScore),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildExplosion(ReadingState state) {
    return EnergyCore(progress: 1.0, isListening: false)
        .animate()
        .scale(
          begin: const Offset(1, 1),
          end: const Offset(3, 3),
          duration: 800.ms,
          curve: Curves.easeInCirc,
        )
        .blur(
          begin: const Offset(0, 0),
          end: const Offset(20, 20),
          duration: 800.ms,
        )
        .fadeOut(delay: 600.ms, duration: 400.ms)
        .callback(
          callback: (_) {
            // Explosion particles could be added here if we had a particle system
          },
        );
  }

  Widget _buildSessionSummary(BuildContext context, ReadingState state) {
    double averageScore = 0;
    if (state.sessionScores.isNotEmpty) {
      averageScore =
          state.sessionScores.reduce((a, b) => a + b) /
          state.sessionScores.length;
    }

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.emoji_events,
              size: 80,
              color: Colors.amber,
            ).animate().scale(
              delay: 200.ms,
              duration: 600.ms,
              curve: Curves.elasticOut,
            ),
            const SizedBox(height: 24),
            Text(
              "¡Sesión Completada!",
              style: Theme.of(
                context,
              ).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text(
              "Puntuación Final: ${(averageScore * 100).toInt()}%",
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 32),
            OutlinedButton(
              onPressed: () {
                setState(() {
                  _showSummary = false;
                });
                context.read<ReadingBloc>().add(LoadReadingSession());
              },
              child: const Text("Practicar de Nuevo"),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => context.pop(),
              child: const Text("Volver al Inicio"),
            ),
          ],
        ),
      ),
    ).animate().fadeIn().scale();
  }

  Widget _buildHighlightedText(
    BuildContext context,
    String target,
    ReadingState state,
  ) {
    final recognizedWords = state.recognizedText
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(' ');

    List<InlineSpan> spans = [];
    final originalWords = target.split(' ');

    for (int i = 0; i < originalWords.length; i++) {
      String cleanWord = originalWords[i].toLowerCase().replaceAll(
        RegExp(r'[^\w\s]'),
        '',
      );

      Color color;
      FontWeight weight;

      if (recognizedWords.contains(cleanWord)) {
        color = Colors.greenAccent;
        weight = FontWeight.bold;
      } else {
        bool isFuzzy = false;
        for (final w in recognizedWords) {
          if (cleanWord.length > 3 && _levenshtein(cleanWord, w) <= 2) {
            isFuzzy = true;
            break;
          }
        }

        if (isFuzzy) {
          color = Colors.yellowAccent;
          weight = FontWeight.w600;
        } else {
          color =
              Theme.of(
                context,
              ).textTheme.bodyLarge?.color?.withValues(alpha: 0.6) ??
              Colors.grey;
          weight = FontWeight.normal;
        }
      }

      spans.add(
        TextSpan(
          text: "${originalWords[i]} ",
          style: GoogleFonts.inter(
            fontSize: 24,
            height: 1.6,
            color: color,
            fontWeight: weight,
          ),
        ),
      );
    }

    return AnimatedSwitcher(
      duration: 600.ms,
      transitionBuilder: (Widget child, Animation<double> animation) {
        return SlideTransition(
          position:
              Tween<Offset>(
                begin: const Offset(0.0, 0.5),
                end: Offset.zero,
              ).animate(
                CurvedAnimation(parent: animation, curve: Curves.easeOutBack),
              ),
          child: FadeTransition(opacity: animation, child: child),
        );
      },
      child: RichText(
        key: ValueKey<String>(target),
        textAlign: TextAlign.center,
        text: TextSpan(children: spans),
      ),
    );
  }

  int _levenshtein(String s, String t) {
    if (s == t) return 0;
    if (s.isEmpty) return t.length;
    if (t.isEmpty) return s.length;

    List<int> v0 = List<int>.filled(t.length + 1, 0);
    List<int> v1 = List<int>.filled(t.length + 1, 0);

    for (int i = 0; i < t.length + 1; i++) v0[i] = i;

    for (int i = 0; i < s.length; i++) {
      v1[0] = i + 1;

      for (int j = 0; j < t.length; j++) {
        int cost = (s.codeUnitAt(i) == t.codeUnitAt(j)) ? 0 : 1;
        v1[j + 1] = [
          v1[j] + 1,
          v0[j + 1] + 1,
          v0[j] + cost,
        ].reduce((a, b) => a < b ? a : b);
      }

      for (int j = 0; j < t.length + 1; j++) v0[j] = v1[j];
    }

    return v1[t.length];
  }

  void _showBubbleMessage(
    BuildContext context,
    String message, {
    bool isError = false,
  }) {
    final overlay = Overlay.of(context);
    final overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        bottom: 120,
        left: 24,
        right: 24,
        child: Material(
          color: Colors.transparent,
          child: Center(
            child:
                Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: isError
                            ? Colors.redAccent.withValues(alpha: 0.95)
                            : const Color(0xFF1A1A1A).withValues(alpha: 0.95),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(
                          color: isError ? Colors.transparent : Colors.white24,
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.4),
                            blurRadius: 15,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            isError
                                ? Icons.error_rounded
                                : Icons.auto_awesome_rounded,
                            color: isError
                                ? Colors.white
                                : const Color(0xFF00E676),
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Flexible(
                            child: Text(
                              message,
                              style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                    .animate()
                    .fadeIn(duration: 400.ms)
                    .slideY(begin: 1, end: 0, curve: Curves.easeOutBack)
                    .then(delay: 2.seconds)
                    .fadeOut(duration: 400.ms)
                    .slideY(begin: 0, end: -0.5),
          ),
        ),
      ),
    );

    overlay.insert(overlayEntry);
    Future.delayed(const Duration(milliseconds: 2800), () {
      overlayEntry.remove();
    });
  }
}
